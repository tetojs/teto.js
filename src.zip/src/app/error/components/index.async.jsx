import React, { Component } from 'react'

export default class extends Component {

  // constructor(props, context) {
  //   super(props, context)
  // }

  render () {
    return (
      <div>404</div>
    )
  }

}
