import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'

// import Message from 'utils/message'
// import { PENDING, SUCCESS, FAILURE, FINALLY } from 'utils/states'

import { userLogout } from '../../actions/tokens'

@connect(state => ({
  ...state.tokens
}), dispatch => ({
  ...bindActionCreators({ userLogout }, dispatch)
}))
export default class extends Component {

  static propTypes = {
    token: PropTypes.object,
    userLogout: PropTypes.func.isRequired
  }

  // constructor(props, context) {
  //   super(props, context)
  // }

  componentDidMount () {
    console.group('[componentDidMount]')
    console.log('token', JSON.stringify(this.props.token))
    console.groupEnd('[componentDidMount]')

    this.props.userLogout()
    // const { token } = this.props
    // console.log('[token]', token)

    // if (token) {
    //   this.logout(token.access_token)
    // } else {
    //   this.props.getToken()
    // }

    // const token = auth.getTokens('access_token')

    // if (accessToken) {
    //   this.props.deleteToken(accessToken)
    // } else {
    //   alert('你还没登录')
    // }
  }

  componentWillReceiveProps (props) {
    console.group('[componentWillReceiveProps]')
    console.log('token', JSON.stringify(props.token))
    console.groupEnd('[componentWillReceiveProps]')

    // switch (meta.state) {
    //   case SUCCESS:
    //     return
    //   default:
    //     // NOTHING
    // }

    // this.props.userLogout()
  }

  render () {
    return (
      <div>...</div>
    )
  }

}
