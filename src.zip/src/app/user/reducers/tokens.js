import { appendReducer, modifyReducer } from 'store'
import { handleActions } from 'redux-actions'

// import { PENDING/*, SUCCESS, FAILURE*/, FINALLY } from 'utils/states'

const tokens = handleActions({
  USER_LOGIN: (state, action) => ({
    token: action.payload
  }),

  USER_LOGOUT: (state, action) => ({
    token: action.payload
  })
}, {
  // meta: {
    // state: FINALLY,
    // message: ''
  // },
  token: null
})

// const tokens = modifyReducer((state = {
//   meta: {
//     state: FINALLY,
//     message: ''
//   },
//   token: null
// }, action) => {
//   let { meta, payload } = action

//   if (meta.state & (PENDING | FINALLY)) {
//     payload = state.token
//   }

//   switch (action.type) {
//     case 'USER_LOGIN':
//       return {
//         meta: meta,
//         token: payload
//       }
//     case 'USER_LOGOUT':
//       return {
//         meta: meta,
//         token: payload
//       }
//     default:
//       return state
//   }
// })

export default appendReducer({ tokens })
