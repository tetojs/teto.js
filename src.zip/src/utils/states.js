const PENDING = 1
const SUCCESS = 2
const FAILURE = 4
const FINALLY = 8

export default {
  PENDING,
  SUCCESS,
  FAILURE,
  FINALLY
}
